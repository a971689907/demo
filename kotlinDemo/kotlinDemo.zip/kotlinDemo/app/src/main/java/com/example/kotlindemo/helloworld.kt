package com.example.kotlindemo

import java.lang.StringBuilder
import java.util.ArrayList

fun main() {
    var aaa:String = "asdfaf"     //定义可以更改的变量
    val name:String? = "asdfiasdfia"  //定义类似final的变量
    var arr:Array<String> = arrayOf("adfadsfd","adfs")
    var arrList:ArrayList<String> = ArrayList()

    arrList.add("adf")
    arrList.add("asdff")
    arrList.add("adf34")
    arrList.add("adfasdf")
    println(name!!.length)

    for (item in arrList){
        println(item)
    }

    var result = sum(123,235)
    println("result=$result")
    println(sum.invoke(222,333))

    var arrayList:ArrayList<String> = ArrayList()
    arrayList.forEach forEach@{
        if(it == "q") return forEach@
        println(it)
    }
    println("end !!")

    println("------------------------")
//    (0..6).map(::factorial).forEach(::println)
    println((0..6).map(::factorial).fold(StringBuilder()){ acc, i ->  acc.append(i).append(",")})
    println((0..6).joinToString(","))
}

fun factorial(n:Int):Int{
    if(n == 0) return 1;
    return (1..n).reduce{acc, i -> acc*i }
}
var sum = {arg1:Int,arg2:Int->
    println("$arg1 + $arg2 = ${arg1+arg2}")
    arg1+arg2
}