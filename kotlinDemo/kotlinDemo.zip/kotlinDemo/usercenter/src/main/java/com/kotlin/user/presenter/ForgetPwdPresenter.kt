package com.kotlin.user.presenter

import com.kotlin.base.ext.execute
import com.kotlin.base.presenter.BasePresenter
import com.kotlin.base.rx.BaseObserver
import com.kotlin.user.presenter.view.ForgetPwdView
import com.kotlin.user.presenter.view.RegisterView
import com.kotlin.user.service.UserService
import com.kotlin.user.service.impl.UserServiceImpl
import io.reactivex.android.schedulers.AndroidSchedulers

import io.reactivex.schedulers.Schedulers
import org.jetbrains.anko.getStackTraceString
import javax.inject.Inject


class ForgetPwdPresenter @Inject constructor():BasePresenter<ForgetPwdView>() {
    @Inject
    lateinit var  userService:UserService
    fun forgetPwd(mobileCode:String,verifyCode:String){

        //TODO  业务逻辑
        if(!checkNetWork()){
            return
        }
        mView.showLoading()

        userService.forgetPwd(mobileCode,verifyCode)
            .execute(object : BaseObserver<Boolean>(mView){
                override fun onNext(t: Boolean) {
                    if(t){
                        mView.onForgetPwdResult("验证成功")
                    }

                }

                override fun onError(e: Throwable) {
                    mView.onErrorResult(e.message.toString())
                }
            },lifeCircleProvider)



    }


}