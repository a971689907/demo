package com.kotlin.user.ui.activity;

public class test {
    public static void main(String[] args) {
        try {
            System.out.println("aa"+aa());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static int aa() throws Exception{
        int a = 1;
        for (int i=1;i<2;i++){
            try {
                throw new Exception("bb");
            }catch (Exception e){
                throw e;
            }finally {
                return 1;
            }
        }
        return 22;
    }
}
