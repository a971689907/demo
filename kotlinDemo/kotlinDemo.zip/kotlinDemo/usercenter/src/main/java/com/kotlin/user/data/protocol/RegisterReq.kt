package com.kotlin.user.data.protocol

/**
 * 不需要自己动手去写一个 JavaBean，可以直接使用 DataClass
 */
data class RegisterReq(val mobie:String,val pwd:String,val verifyCode:String)