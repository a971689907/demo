package com.kotlin.user.ui.activity

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.kotlin.base.ui.activity.BaseActivity
import com.kotlin.user.R
import kotlinx.android.synthetic.main.layout_testmain_view.*

class TestMainActivity: BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_testmain_view)

        initView()
    }

    private fun initView() {
        var mListData:ArrayList<MyFragment> =  ArrayList()
        mListData.add(MyFragment())
        mListData.add(MyFragment())
        mListData.add(MyFragment())
        mViewPager.adapter = MyPagerAdapter(mListData,supportFragmentManager)
    }



    class MyPagerAdapter(mList:List<MyFragment>,fm:FragmentManager): FragmentStatePagerAdapter(fm){
        private val mlistA: List<MyFragment>? = mList
        private val fmA: FragmentManager? = fm

        override fun getItem(position: Int): Fragment {
            return mlistA!!.get(position)
        }

        override fun getCount(): Int {
            return mlistA!!.size
        }

    }
}