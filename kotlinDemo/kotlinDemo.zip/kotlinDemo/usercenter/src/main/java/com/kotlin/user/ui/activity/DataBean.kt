package com.kotlin.user.ui.activity

data class DataBean(val name:String)