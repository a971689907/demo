package com.kotlin.user.presenter

import com.kotlin.base.ext.execute
import com.kotlin.base.presenter.BasePresenter
import com.kotlin.base.rx.BaseObserver
import com.kotlin.user.data.protocol.UserInfo
import com.kotlin.user.presenter.view.LoginView
import com.kotlin.user.presenter.view.RegisterView
import com.kotlin.user.service.UserService
import com.kotlin.user.service.impl.UserServiceImpl
import io.reactivex.android.schedulers.AndroidSchedulers

import io.reactivex.schedulers.Schedulers
import javax.inject.Inject


class LoginPresenter @Inject constructor():BasePresenter<LoginView>() {
    @Inject
    lateinit var  userService:UserService

    fun login(mobileCode: String, pwd: String, pushId: String){

        //TODO  业务逻辑
        if(!checkNetWork()){return}

        mView.showLoading()
        userService.login(mobileCode,pwd,pushId)
            .execute(object :BaseObserver<UserInfo>(mView){
            override fun onNext(t: UserInfo) {
               mView.onLoginResult(t)
            }
        },lifeCircleProvider)



    }
}