package com.kotlin.user.ui.activity

import android.os.Bundle
import android.view.View
import android.widget.EditText
import com.kotlin.base.ext.enable
import com.kotlin.base.ext.onClick
import com.kotlin.base.ui.activity.BaseMvpActivity
import com.kotlin.base.widgets.VerifyButton
import com.kotlin.user.R
import com.kotlin.user.injection.component.DaggerUserComponent

import com.kotlin.user.injection.module.UserModule

import com.kotlin.user.presenter.RegisterPresenter
import com.kotlin.user.presenter.view.RegisterView
import kotlinx.android.synthetic.main.activity_register.*

import org.jetbrains.anko.toast

class RegisterActivity : BaseMvpActivity<RegisterPresenter>(), RegisterView {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

       initView()
    }

    private fun initView() {
        mRegisterClick.enable(mMobileEt) {isBtnEnable()}
        mRegisterClick.enable(mVerifyCodeEt) {isBtnEnable()}
        mRegisterClick.enable(mPwdEt) {isBtnEnable()}
        mRegisterClick.enable(mPwdConfirmEt) {isBtnEnable()}


        mRegisterClick.onClick { onClickMethod(mRegisterClick) }
        mVerifyCodeBtn.onClick { onClickMethod(mVerifyCodeBtn) }
    }


    override fun onRegisterResult(result: String) {
        toast("result====" + result)
    }

    fun onClickMethod(v: View) {
        when (v.id) {

            R.id.mRegisterClick  -> {
                toast("click" + v.id)

               val result:Boolean = checkPwdEquals(mPwdEt,mPwdConfirmEt)
                if(!result){
                    toast("请两次输入一样的密码")
                    return
                }
                mBasePresenter.register(
                    mMobileEt.text.toString(),
                    "bbb",
                    mPwdEt.text.toString()
                )
            }

            R.id.mVerifyCodeBtn -> {
                mVerifyCodeBtn.requestSendVerifyNumber()
            }
        }
    }
    //检查两次输入密码是否相等
    private fun checkPwdEquals(mPwdEt: EditText?, mPwdConfirmEt: EditText?):Boolean {
        if("" == mPwdEt!!.text.toString()||null == mPwdEt!!.text){
            return false
        }
        if("" == mPwdConfirmEt!!.text.toString()||null == mPwdConfirmEt!!.text){
            return false
        }

       return mPwdEt!!.text.toString().equals(mPwdConfirmEt!!.text.toString())
    }

    override fun initInjectComponent() {
        //这样才算成功注入
        DaggerUserComponent.builder().activityComponent(activityComponent).userModule(UserModule())
            .build().inject(this)
        mBasePresenter.mView = this
    }

    /*
     判断按钮是否可用
  */
    private fun isBtnEnable():Boolean{
        return mMobileEt.text.isNullOrEmpty().not() &&
                mVerifyCodeEt.text.isNullOrEmpty().not() &&
                mPwdEt.text.isNullOrEmpty().not()&&
                mPwdConfirmEt.text.isNullOrEmpty().not()
    }
}