package com.kotlin.user.presenter.view

import com.kotlin.base.presenter.view.BaseView

interface ForgetPwdView:BaseView {

    fun onForgetPwdResult(result:String){

    }
    fun onErrorResult(msg:String){

    }
}