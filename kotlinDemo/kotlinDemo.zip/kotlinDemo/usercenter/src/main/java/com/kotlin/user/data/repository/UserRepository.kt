package com.kotlin.user.data.repository

import com.kotlin.base.data.net.RetrofitFactory
import com.kotlin.base.data.protocol.BaseResp
import com.kotlin.user.data.api.UserApi
import com.kotlin.user.data.protocol.*
import io.reactivex.Observable
import javax.inject.Inject

//正真方法请求的类，封装了service层Impl的方法调用
class UserRepository @Inject constructor() {
    fun register(mobile:String,pwd:String,verifyCode:String): Observable<BaseResp<String>>{
        val userApi = RetrofitFactory.instance.create(UserApi::class.java)
        return userApi .register(RegisterReq(mobile,pwd,verifyCode))

    }

    fun login(mobile:String,pwd:String,pushId:String): Observable<BaseResp<UserInfo>>{
        val userApi = RetrofitFactory.instance.create(UserApi::class.java)
        return userApi .login(LoginReq(mobile,pwd,pushId))

    }


    fun forgetPwd(mobile:String,verifyCode:String): Observable<BaseResp<String>>{
        val userApi = RetrofitFactory.instance.create(UserApi::class.java)
        return userApi .forgetPwd(ForgetPwdReq(mobile,verifyCode))

    }

    fun resetPwd(mobile:String,pwd:String): Observable<BaseResp<String>>{
        val userApi = RetrofitFactory.instance.create(UserApi::class.java)
        return userApi .resetPwd(ResetPwdReq(mobile,pwd))

    }
}