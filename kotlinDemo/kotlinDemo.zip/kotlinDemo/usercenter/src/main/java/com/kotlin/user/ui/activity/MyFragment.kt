package com.kotlin.user.ui.activity

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.kotlin.user.R
import kotlinx.android.synthetic.main.layout_testfragment_view.*

class MyFragment :Fragment(){
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       var mView:View = inflater.inflate(R.layout.layout_testfragment_view,null,false);
        return mView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initData()
    }

    private fun initData() {
        var bean = DataBean("aaa")
        if (getArguments()!=null){
            bean= arguments!!.getSerializable("DataBean") as DataBean

        }

       var mView:View = LayoutInflater.from(context).inflate(R.layout.layout_item_addview,null,false)

        mFragmentContainer.addView(mView)
        Log.e("wangyan","bean---->"+bean.name)
    }
}