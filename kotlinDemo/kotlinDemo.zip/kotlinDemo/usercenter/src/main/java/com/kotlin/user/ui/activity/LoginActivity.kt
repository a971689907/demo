package com.kotlin.user.ui.activity

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import com.kotlin.base.ext.enable
import com.kotlin.base.ext.onClick
import com.kotlin.base.ui.activity.BaseMvpActivity
import com.kotlin.base.widgets.VerifyButton
import com.kotlin.user.R
import com.kotlin.user.data.protocol.UserInfo
import com.kotlin.user.injection.component.DaggerUserComponent

import com.kotlin.user.injection.module.UserModule
import com.kotlin.user.presenter.LoginPresenter

import com.kotlin.user.presenter.RegisterPresenter
import com.kotlin.user.presenter.view.LoginView
import com.kotlin.user.presenter.view.RegisterView
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.mMobileEt
import kotlinx.android.synthetic.main.activity_register.mPwdEt
import org.jetbrains.anko.startActivity


import org.jetbrains.anko.toast
import kotlinx.android.synthetic.main.activity_register.mHeaderBar as mHeaderBar1

class LoginActivity : BaseMvpActivity<LoginPresenter>(), LoginView {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

       initView()
    }

    private fun initView() {
        mLoginBtn.enable(mMobileEt) {isBtnEnable()}
        mLoginBtn.enable(mPwdEt) {isBtnEnable()}

        mLoginBtn.onClick { onClickMethod(mLoginBtn) }
        mForgetPwdTv.onClick { onClickMethod(mForgetPwdTv) }


        mHeaderBar.getRightView().onClick{onClickMethod(mHeaderBar.getRightView())}

        testAddView()
    }

    private fun testAddView() {
      var mView:View =  LayoutInflater.from(this).inflate(R.layout.layout_item_addview,null,false)
        ll_container.addView(mView)

    }


    override fun onLoginResult(result: UserInfo) {
        toast("登陆成功")
    }

    fun onClickMethod(v: View) {
        when (v.id) {

            R.id.mLoginBtn -> {
               mBasePresenter.login(mMobileEt.text.toString(),mPwdEt.text.toString(),"")
            }

            R.id.mRightTv->{
//                toast("点击注册")
                startActivity<RegisterActivity>()
            }
            R.id.mForgetPwdTv->{
                startActivity<ForgetPwdActivity>()
            }
        }
    }

    override fun initInjectComponent() {
        //这样才算成功注入
        DaggerUserComponent.builder().activityComponent(activityComponent).userModule(UserModule())
            .build().inject(this)
        mBasePresenter.mView = this
    }

    /*
     判断按钮是否可用
  */
    private fun isBtnEnable():Boolean{
        return mMobileEt.text.isNullOrEmpty().not() &&
                mPwdEt.text.isNullOrEmpty().not()
    }
}