package com.kotlin.base.ui.fragment

import com.trello.rxlifecycle3.components.RxFragment

open class BaseFragment : RxFragment(){

}