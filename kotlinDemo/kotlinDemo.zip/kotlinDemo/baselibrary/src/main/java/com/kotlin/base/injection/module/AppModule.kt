package com.kotlin.base.injection.module

import android.app.Application
import android.content.Context
import com.kotlin.base.common.BaseApplication
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class AppModule ( context: BaseApplication){
    val mContext = context

    @Provides
    @Singleton
    fun providerContext(): Context {
        return mContext
    }
}