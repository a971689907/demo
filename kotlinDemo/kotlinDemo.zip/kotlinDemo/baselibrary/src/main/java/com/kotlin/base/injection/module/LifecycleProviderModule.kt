package com.kotlin.base.injection.module

import android.app.Activity
import com.trello.rxlifecycle3.LifecycleProvider
import dagger.Module
import dagger.Provides

@Module
class LifecycleProviderModule(lifecycleProvider: LifecycleProvider<*>) {
    val mLifecycleProvider = lifecycleProvider
    @Provides
    fun providerLifecycleProvider(): LifecycleProvider<*> {
        return mLifecycleProvider
    }
}