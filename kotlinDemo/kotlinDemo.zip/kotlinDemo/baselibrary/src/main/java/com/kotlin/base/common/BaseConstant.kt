package com.kotlin.base.common

class BaseConstant {
    companion object{
        const val SERVER_ADDRESS = "http://www.baidu.com"
        const val TABLE_PREFS = "Kotlin_mall"
    }
}