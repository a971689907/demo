package com.kotlin.base.data.protocol

/**
 * in修饰的泛型只能是传入参数，out修饰的只能是返回类型
 * in修饰的类型只能向下兼容，编译器允许转换右边的类型被转换成子类
 * out修饰的类型在泛型接口实现后相互转换时，
 * 左边的该类型只能是右边该类型的同类或父类。简单来说out修饰的类型只能向上兼容。
 */
class BaseResp<T>(val status:Int,val message:String,val data:T) {

}