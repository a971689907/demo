package com.kotlin.base.rx

class BaseException(val status:Int,val msg:String):Throwable() {
}